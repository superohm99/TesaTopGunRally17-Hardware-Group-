#ifndef __MAIN_H__
#define __MAIN_H__

// include files
#include <Arduino.h>
#include <Esp.h>
#include <esp_log.h>

// shared variables

// public function prototypes

#endif  // __MAIN_H__